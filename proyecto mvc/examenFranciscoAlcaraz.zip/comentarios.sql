-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:33065
-- Tiempo de generación: 15-12-2022 a las 12:20:40
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `examenfas_48464557s`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
CREATE TABLE `comentarios` (
  `titulo` varchar(50) NOT NULL,
  `autor` varchar(20) NOT NULL,
  `comentario` varchar(200) NOT NULL,
  `autor_comentario` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`titulo`, `autor`, `comentario`, `autor_comentario`) VALUES
('A DORMIR! LA GRANJA', 'CHARLOTTE ROEDERER', 'Para compartir el momento de dormir con tu bebé', 'usuario2'),
('APRENDE A IR AL BAÑO CON BLUE', 'VV.AA', 'Blue va al baño y tú también puedes hacerlo. ¡Presiona los botonos y tira de la cadena mientras lees el cuento!', 'pepe'),
('CHU CHU, SILTA EL TREN', 'ANGEL CARMONA', 'Una dulce niña viaja por distintos hábitats animales e interacciona con ellos durante el transcurso de un día, desde el amanecer hasta el anochecer', 'usuario1'),
('PEPE Y MILA Y LAS ESTACIONES', 'YAYO KAWAMURA', 'Un divertido libro con ruedas, lengüetas y otros elementos móviles para que los más pequeños descubran las estaciones con Pepe y Mila.', 'usuario1');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`titulo`),
  ADD KEY `fk_1` (`autor_comentario`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD CONSTRAINT `fk_1` FOREIGN KEY (`autor_comentario`) REFERENCES `usuarios` (`nombre`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
