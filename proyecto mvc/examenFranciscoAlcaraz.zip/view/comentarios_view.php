<?php 
require_once("menu_view.php");
require_once("tabla_view.php");


?>

    